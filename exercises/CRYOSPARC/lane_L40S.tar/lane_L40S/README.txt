####################
# L40S Nodes Specs #
####################

Number of nodes:	10
Node names: 		
CPU model:		AMD Zen4
# of CPU cores:	2x24
# of GPU CUDA cores:	2x####
VRAM:			48 GB
RAM:			384GB
Scratch:		1.9 TB NVMe disk
