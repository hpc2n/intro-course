A100 nodes specs

Number of nodes: 2
CPU: AMD Zen3 (AMD EPYC 7413)
NUmber of CPU cores: 2x24
Number of GPU CUDA cores: 2x6912
RAM: 512GB
