H100 nodes specs

Number of nodes: 2
CPU: AMD Zen4
NUmber of CPU cores: 2x48
Number of GPU CUDA cores: 4x####
RAM: 768GB
Scratch: 3.8 TB NVMe disk
