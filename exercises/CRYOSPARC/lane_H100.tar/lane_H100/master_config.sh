# Instance Configuration
export CRYOSPARC_LICENSE_ID=8ba98f0a-6152-11ef-97c3-c71531595d77
export CRYOSPARC_MASTER_HOSTNAME=
export CRYOSPARC_DB_PATH=/home/p/pojedama/po_hpc/cryosparc/database
export CRYOSPARC_BASE_PORT=
export CRYOSPARC_DB_CONNECTION_TIMEOUT_MS=20000

# Security
export CRYOSPARC_INSECURE=false
export CRYOSPARC_DB_ENABLE_AUTH=true

# Cluster Integration
export CRYOSPARC_CLUSTER_JOB_MONITOR_INTERVAL=10
export CRYOSPARC_CLUSTER_JOB_MONITOR_MAX_RETRIES=1000000

# Project Configuration
export CRYOSPARC_PROJECT_DIR_PREFIX='CS-'

# Development
export CRYOSPARC_DEVELOP=false

# Other
export CRYOSPARC_CLICK_WRAP=true
export CRYOSPARC_FORCE_HOSTNAME=true
export CRYOSPARC_FORCE_USER=true
export CRYOSPARC_DATA_DIR=/home/p/pojedama/po_hpc/cryosparc
export CRYOSPARC_SUPERVISOR_SOCK_FILE=/tmp/cryosparc-supervisor-$(echo -n $CRYOSPARC_DATA_DIR | md5sum | awk '{print $1}').sock
